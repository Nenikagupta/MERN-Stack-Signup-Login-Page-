const express = require('express');
const bodyparser = require('body-parser');
const mongoose = require('mongoose');
const cookieparser = require('cookie-parser');
const User=require('../../models/user_master');

const router=express.Router();

router.use(bodyparser.json());



router.get("/", async(req, res, next) => {
  try{

    req.logout();

    res.json({
      title:'User loged out Successfully',
    });
  }catch(err){
    res.status(401).json({
      errorMessage:err.message
    });
  }
});

module.exports=router;
