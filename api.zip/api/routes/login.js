const express = require('express');
const bodyparser = require('body-parser');
const mongoose = require('mongoose');
const cookieparser = require('cookie-parser');
const session = require('express-session');
const passport = require("passport");
const passportLocalMongoose = require("passport-local-mongoose");
const User=require('../../models/user_master');

const app=express();

const router=express.Router();


router.use(bodyparser.json());

//session///

app.use(session({
  secret: "Our little secret.",
  resave: false,
  saveUninitialized: false
}));


passport.use(User.createStrategy());

passport.serializeUser(function(user, done) {
  done(null, user.id);
});

passport.deserializeUser(function(id, done) {
  User.findById(id, function(err, user) {
    done(err, user);
  });
});


////route///////////

router.post("/",async(req,res,next) => {
  try{
    const user = new User({
      username: req.body.username,
      password: req.body.password
    });


    req.login(user, function(err){
      if (err) {
         res.status(400).json({
          errors:
            {
              title: 'Invalid Credentials',
              errorMessage: err.message,
            }
        });
      } else {
        passport.authenticate("local")(req, res, function(){
          User.findOne({username:user.username},function(err,foundUser){
            if(err){
              res.status(401).json({
                errors: [
                  {
                    title: 'Error',
                    errorMessage: err.message,
                  },
                ],
              });
            }else{
              res.status(200).json({
                title:'Successfully user login',
                details:'Valid username and password',
              });
            }
          });
        });
      }
    });
  } catch(err){
    res.status(401).json({
      errors: [
        {
          title: 'Error',
          errorMessage: err.message,
        },
      ],
    });
  }
  });


  module.exports=router;
