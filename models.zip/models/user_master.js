const mongoose=require('mongoose');
const uniquevalidator = require('mongoose-unique-validator');
const passportLocalMongoose = require("passport-local-mongoose");

const UserSchema=new mongoose.Schema({
  fname:{type:String,
        required:true},
  lname:{type:String,
              required:true},
  password:{type:String,
        //required:true,
        minlength:8},
  resetPasswordToken:String,
  resetPasswordExpires:Date

});

UserSchema.plugin(uniquevalidator);

UserSchema.plugin(passportLocalMongoose);


module.exports=mongoose.model("User",UserSchema);
